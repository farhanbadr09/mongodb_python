from bitpay.client import Client
client = Client(api_uri="https://test.bitpay.com") #if api_uri is not passed, it defaults to "https://bitpay.com"
client.pair_pos_client("abcdefg")

client.create_invoice({"price": 20, "currency": "USD", "token": client.tokens['pos']})
